package com.nexapp.nexmusic.ui.screens.musicflow

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.nexapp.nexmusic.LocalDatabase
import com.nexapp.nexmusic.LocalDownloadUtil
import com.nexapp.nexmusic.LocalExpandPlayer
import com.nexapp.nexmusic.LocalPlayerConnection
import com.nexapp.nexmusic.LocalSyncUtils
import com.nexapp.nexmusic.R
import com.nexapp.nexmusic.db.MusicDatabase
import com.nexapp.nexmusic.db.entities.LyricsEntity
import com.nexapp.nexmusic.db.entities.Song
import com.nexapp.nexmusic.db.entities.SongEntity
import com.nexapp.nexmusic.models.toMediaMetadata
import com.nexapp.nexmusic.models.toSongEntity
import com.nexapp.nexmusic.playback.ExoDownloadService
import com.nexapp.nexmusic.playback.PlayerConnection
import com.nexapp.nexmusic.musicflow.MusicFlowFeedError
import com.nexapp.nexmusic.musicflow.MusicFlowItem
import com.nexapp.nexmusic.musicflow.MusicFlowPlaybackStatus
import com.nexapp.nexmusic.musicflow.MusicFlowUiState
import com.nexapp.nexmusic.musicflow.TakeoverBlock
import com.nexapp.nexmusic.ui.component.LocalMenuState
import com.nexapp.nexmusic.ui.component.musicflow.MusicFlowPage
import com.nexapp.nexmusic.ui.component.musicflow.MusicFlowPageActions
import com.nexapp.nexmusic.ui.component.musicflow.MusicFlowPagePlaceholder
import com.nexapp.nexmusic.ui.menu.AddToPlaylistDialog
import com.nexapp.nexmusic.ui.menu.YouTubeSongMenu
import com.nexapp.nexmusic.ui.player.InlineLyricsView
import com.nexapp.nexmusic.utils.SyncUtils
import com.nexapp.nexmusic.viewmodels.MusicFlowViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Composable
fun MusicFlowScreen(
  navController: NavController,
  viewModel: MusicFlowViewModel = hiltViewModel(),
) {
  val context = LocalContext.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val database = LocalDatabase.current
  val syncUtils = LocalSyncUtils.current
  val downloadUtil = LocalDownloadUtil.current
  val menuState = LocalMenuState.current
  val expandPlayer = LocalExpandPlayer.current
  val scope = rememberCoroutineScope()

  DisposableEffect(playerConnection) {
    viewModel.attach(playerConnection)
    onDispose { viewModel.detach() }
  }
  KeepLightSystemBarIcons()

  val state by viewModel.uiState.collectAsState()
  val preferences by viewModel.preferences.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val currentLyrics by playerConnection.currentLyrics.collectAsState(initial = null)
  val currentMediaId = mediaMetadata?.id

  val reduceMotion = remember { context.isReducedMotion() }
  val showCanvas = preferences.animatedBackground && !preferences.dataSaver && !reduceMotion
  val allowArtPrefetch = remember(preferences) {
    !preferences.dataSaver && (preferences.cellularPrefetch || !context.isActiveNetworkMetered())
  }

  var progress by remember(currentMediaId) { mutableFloatStateOf(0f) }
  LaunchedEffect(playerConnection, currentMediaId) {
    while (isActive) {
      val (position, duration) = playerConnection.positionAndDuration()
      progress = if (duration > 0) position.toFloat() / duration else 0f
      delay(POSITION_POLL_MS)
    }
  }

  val lyricsReady = currentLyrics.isUsableFor(currentMediaId)

  var lyricsExpanded by rememberSaveable { mutableStateOf(false) }
  var playlistTarget by remember { mutableStateOf<SongItem?>(null) }
  BackHandler(enabled = lyricsExpanded) { lyricsExpanded = false }

  val items = state.items
  val hasTrailingPage = items.isNotEmpty() && (state.isLoadingMore || !state.hasMore || state.error != null)
  val pageCount = items.size + if (hasTrailingPage) 1 else 0
  val pagerState = rememberPagerState(initialPage = state.selectedIndex) { pageCount }

  LaunchedEffect(pagerState) {
    snapshotFlow { pagerState.settledPage }.distinctUntilChanged().collect(viewModel::onPageSettled)
  }
  var shownItemCount by remember { mutableIntStateOf(items.size) }
  LaunchedEffect(state.selectedIndex, items.size) {
    val settled = pagerState.settledPage
    val wasOnTrailingPage = shownItemCount > 0 && settled >= shownItemCount
    shownItemCount = items.size
    if (pagerState.isScrollInProgress || items.isEmpty()) return@LaunchedEffect
    if (wasOnTrailingPage && settled in items.indices) {
      viewModel.onPageSettled(settled)
      return@LaunchedEffect
    }
    val target = state.selectedIndex
    if (target < pageCount && settled != target) {
      if (reduceMotion) pagerState.scrollToPage(target) else pagerState.animateScrollToPage(target)
    }
  }

  val selectedItem = items.getOrNull(state.selectedIndex)
  val previousLabel = stringResource(R.string.music_flow_previous)
  val nextLabel = stringResource(R.string.music_flow_next)

  Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
    when {
      items.isEmpty() && state.error != null && !state.isInitialLoading ->
        FeedMessage(
          message = stringResource(state.error!!.messageRes()),
          action = stringResource(R.string.retry),
          onAction = viewModel::retryFeed,
        )
      items.isEmpty() -> MusicFlowPagePlaceholder()
      else ->
        VerticalPager(
          state = pagerState,
          beyondViewportPageCount = if (allowArtPrefetch) 1 else 0,
          userScrollEnabled = !lyricsExpanded,
          key = { page -> items.getOrNull(page)?.songId ?: "music_flow_trailing_$page" },
          modifier =
            Modifier.fillMaxSize().semantics {
              customActions =
                listOf(
                  CustomAccessibilityAction(previousLabel) { viewModel.previous(); true },
                  CustomAccessibilityAction(nextLabel) { viewModel.next(); true },
                )
            },
        ) { page ->
          val item = items.getOrNull(page)
          when {
            item != null -> {
              val librarySong by database.song(item.songId).collectAsState(initial = null)
              val download by downloadUtil.getDownload(item.songId).collectAsState(initial = null)
              val isCurrent = item.songId == currentMediaId
              MusicFlowPage(
                item = item,
                isCurrentPlayback = isCurrent,
                isPlaying = isPlaying,
                isLiked = librarySong?.song?.liked == true,
                downloadState = download?.state,
                showCanvas = showCanvas && page == state.selectedIndex,
                lyricsAvailable = isCurrent && lyricsReady,
                showLyrics = isCurrent && preferences.lyrics,
                progress = { progress },
                actions =
                  MusicFlowPageActions(
                    onTogglePlay = viewModel::togglePlayPause,
                    onLike = { toggleLike(database, syncUtils, item.song, librarySong) },
                    onAddToPlaylist = { playlistTarget = item.song },
                    onLyrics = { lyricsExpanded = true },
                    onShare = { context.shareSong(item.song) },
                    onDownload = { toggleDownload(context, database, item.song, download?.state) },
                    onMore = {
                      menuState.show {
                        YouTubeSongMenu(song = item.song, navController = navController, onDismiss = menuState::dismiss)
                      }
                    },
                    onArtist = { navController.navigate("artist/$it") },
                    onSeek = { fraction ->
                      val (_, duration) = playerConnection.positionAndDuration()
                      if (duration > 0) {
                        progress = fraction
                        playerConnection.seekTo((duration * fraction).toLong())
                      }
                    },
                  ),
              )
            }
            state.isLoadingMore -> MusicFlowPagePlaceholder()
            state.error != null ->
              FeedMessage(
                message = stringResource(state.error!!.messageRes()),
                action = stringResource(R.string.retry),
                onAction = viewModel::loadMoreIfNeeded,
              )
            else ->
              FeedMessage(
                message = stringResource(R.string.music_flow_end),
                action = stringResource(R.string.music_flow_start_over),
                onAction = viewModel::retryFeed,
              )
          }
        }
    }

    TopBar(
      state = state,
      selectedItem = selectedItem,
      onBack = navController::navigateUp,
      onPrevious = viewModel::previous,
      onNext = viewModel::next,
      onOpenPlayer = {
        navController.navigateUp()
        expandPlayer()
      },
      onRestoreQueue = {
        val restored = viewModel.restorePreviousQueue()
        Toast.makeText(
            context,
            if (restored) R.string.music_flow_queue_restored else R.string.music_flow_queue_restore_unavailable,
            Toast.LENGTH_SHORT,
          )
          .show()
      },
      onNotInterested = { item, persist ->
        viewModel.notInterested(item, persist)
        Toast.makeText(context, R.string.music_flow_feedback_saved, Toast.LENGTH_SHORT).show()
      },
      onLessLikeThis = { item ->
        viewModel.lessLikeThis(item)
        Toast.makeText(context, R.string.music_flow_feedback_saved, Toast.LENGTH_SHORT).show()
      },
      onSettings = { navController.navigate("settings/music_flow") },
      onStatusAction = viewModel::togglePlayPause,
      onRetryPlayback = viewModel::retryPlayback,
      onSkip = viewModel::next,
      hasPlaybackError = playerConnection.error.collectAsState().value != null && selectedItem?.songId == currentMediaId,
    )

    AnimatedVisibility(visible = lyricsExpanded, enter = fadeIn(), exit = fadeOut()) {
      Box(
        modifier =
          Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f))
            .windowInsetsPadding(WindowInsets.safeDrawing)
      ) {
        InlineLyricsView(
          mediaMetadata = mediaMetadata,
          showLyrics = true,
          modifier = Modifier.fillMaxSize().padding(top = 64.dp, start = 16.dp, end = 16.dp),
          positionProvider = { playerConnection.player.currentPosition },
        )
        IconButton(onClick = { lyricsExpanded = false }, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
          Icon(painterResource(R.drawable.close), contentDescription = stringResource(R.string.close), tint = Color.White)
        }
      }
    }
  }

  playlistTarget?.let { song ->
    AddToPlaylistDialog(
      isVisible = true,
      onGetSong = { playlist ->
        database.withTransaction { insert(song.toMediaMetadata()) }
        scope.launch(Dispatchers.IO) {
          playlist.playlist.browseId?.let { browseId -> YouTube.addToPlaylist(browseId, song.id) }
        }
        listOf(song.id)
      },
      onDismiss = { playlistTarget = null },
    )
  }
}

@Composable
private fun TopBar(
  state: MusicFlowUiState,
  selectedItem: MusicFlowItem?,
  onBack: () -> Unit,
  onPrevious: () -> Unit,
  onNext: () -> Unit,
  onOpenPlayer: () -> Unit,
  onRestoreQueue: () -> Unit,
  onNotInterested: (MusicFlowItem, Boolean) -> Unit,
  onLessLikeThis: (MusicFlowItem) -> Unit,
  onSettings: () -> Unit,
  onStatusAction: () -> Unit,
  onRetryPlayback: () -> Unit,
  onSkip: () -> Unit,
  hasPlaybackError: Boolean,
) {
  var menuExpanded by remember { mutableStateOf(false) }
  Column(modifier = Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing)) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
      IconButton(onClick = onBack) {
        Icon(painterResource(R.drawable.arrow_back), contentDescription = stringResource(R.string.back_button_desc), tint = Color.White)
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.music_flow),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = Color.White,
        )
        if (state.isOfflineFeed) {
          Text(
            text = stringResource(R.string.music_flow_offline_banner),
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.6f),
          )
        }
      }
      Box {
        IconButton(onClick = { menuExpanded = true }) {
          Icon(painterResource(R.drawable.more_vert), contentDescription = stringResource(R.string.more_options), tint = Color.White)
        }
        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
          if (state.selectedIndex > 0) {
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_previous)) }, onClick = { menuExpanded = false; onPrevious() })
          }
          if (state.selectedIndex < state.items.lastIndex) {
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_next)) }, onClick = { menuExpanded = false; onNext() })
          }
          DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_open_player)) }, onClick = { menuExpanded = false; onOpenPlayer() })
          if (state.canRestorePreviousQueue) {
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_restore_queue)) }, onClick = { menuExpanded = false; onRestoreQueue() })
          }
          selectedItem?.let { item ->
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_not_interested)) }, onClick = { menuExpanded = false; onNotInterested(item, false) })
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_less_like_this)) }, onClick = { menuExpanded = false; onLessLikeThis(item) })
            DropdownMenuItem(text = { Text(stringResource(R.string.music_flow_never_recommend)) }, onClick = { menuExpanded = false; onNotInterested(item, true) })
          }
          DropdownMenuItem(text = { Text(stringResource(R.string.settings)) }, onClick = { menuExpanded = false; onSettings() })
        }
      }
    }

    val status = statusMessage(state.playbackStatus, hasPlaybackError)
    AnimatedVisibility(visible = status != null, modifier = Modifier.align(Alignment.CenterHorizontally)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier =
          Modifier.padding(top = 4.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .clickable(enabled = state.playbackStatus == MusicFlowPlaybackStatus.ExternalOverride && !hasPlaybackError, onClick = onStatusAction)
            .padding(horizontal = 16.dp, vertical = 6.dp),
      ) {
        Text(text = status.orEmpty(), style = MaterialTheme.typography.labelLarge, color = Color.White)
        if (hasPlaybackError) {
          TextButton(onClick = onRetryPlayback) { Text(stringResource(R.string.retry), color = Color.White) }
          TextButton(onClick = onSkip) { Text(stringResource(R.string.music_flow_skip), color = Color.White) }
        }
      }
    }
  }
}

@Composable
private fun statusMessage(status: MusicFlowPlaybackStatus, hasPlaybackError: Boolean): String? =
  when {
    hasPlaybackError -> stringResource(R.string.music_flow_playback_error)
    status is MusicFlowPlaybackStatus.Blocked ->
      stringResource(
        when (status.reason) {
          TakeoverBlock.CASTING -> R.string.music_flow_blocked_casting
          TakeoverBlock.LISTEN_TOGETHER_GUEST -> R.string.music_flow_blocked_listen_together
        }
      )
    status == MusicFlowPlaybackStatus.ExternalOverride -> stringResource(R.string.music_flow_external)
    status == MusicFlowPlaybackStatus.Switching -> stringResource(R.string.music_flow_buffering)
    else -> null
  }

@Composable
private fun FeedMessage(message: String, action: String, onAction: () -> Unit) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
    modifier = Modifier.fillMaxSize().padding(32.dp),
  ) {
    Text(
      text = message,
      style = MaterialTheme.typography.titleMedium,
      color = Color.White,
      textAlign = TextAlign.Center,
    )
    Spacer(Modifier.height(20.dp))
    Button(
      onClick = onAction,
      shape = RoundedCornerShape(24.dp),
      colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
      elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
    ) {
      Text(action)
    }
  }
}

@Composable
private fun KeepLightSystemBarIcons() {
  val view = LocalView.current
  DisposableEffect(view) {
    val window = (view.context as? Activity)?.window
    val controller = window?.let { WindowCompat.getInsetsController(it, view) }
    val previousStatus = controller?.isAppearanceLightStatusBars
    val previousNavigation = controller?.isAppearanceLightNavigationBars
    controller?.isAppearanceLightStatusBars = false
    controller?.isAppearanceLightNavigationBars = false
    onDispose {
      previousStatus?.let { controller.isAppearanceLightStatusBars = it }
      previousNavigation?.let { controller.isAppearanceLightNavigationBars = it }
    }
  }
}

private fun MusicFlowFeedError.messageRes() =
  when (this) {
    MusicFlowFeedError.OFFLINE -> R.string.music_flow_offline
    MusicFlowFeedError.EMPTY -> R.string.music_flow_empty
    MusicFlowFeedError.FAILED -> R.string.music_flow_failed
  }

private fun LyricsEntity?.isUsableFor(mediaId: String?): Boolean =
  this != null && mediaId != null && id == mediaId && lyrics.isNotBlank() && lyrics != LyricsEntity.LYRICS_NOT_FOUND

private fun toggleLike(database: MusicDatabase, syncUtils: SyncUtils, song: SongItem, librarySong: Song?) {
  database.transaction {
    val updated: SongEntity =
      if (librarySong == null) {
        insert(song.toMediaMetadata(), SongEntity::toggleLike)
        song.toMediaMetadata().toSongEntity().let(SongEntity::toggleLike)
      } else {
        librarySong.song.toggleLike().also(::update)
      }
    syncUtils.likeSong(updated)
  }
}

private fun toggleDownload(context: Context, database: MusicDatabase, song: SongItem, state: Int?) {
  when (state) {
    Download.STATE_COMPLETED,
    Download.STATE_QUEUED,
    Download.STATE_DOWNLOADING ->
      DownloadService.sendRemoveDownload(context, ExoDownloadService::class.java, song.id, false)
    else -> {
      database.transaction { insert(song.toMediaMetadata()) }
      val request =
        DownloadRequest.Builder(song.id, song.id.toUri())
          .setCustomCacheKey(song.id)
          .setData(song.title.toByteArray())
          .build()
      DownloadService.sendAddDownload(context, ExoDownloadService::class.java, request, false)
    }
  }
}

private fun Context.shareSong(song: SongItem) {
  val intent =
    Intent().apply {
      action = Intent.ACTION_SEND
      type = "text/plain"
      putExtra(Intent.EXTRA_TEXT, song.shareLink)
    }
  startActivity(Intent.createChooser(intent, null))
}

private fun PlayerConnection.positionAndDuration(): Pair<Long, Long> {
  val castHandler = service.castConnectionHandler
  return if (castHandler?.isCasting?.value == true) {
    castHandler.castPosition.value to castHandler.castDuration.value
  } else {
    player.currentPosition to player.duration
  }
}

private fun Context.isReducedMotion(): Boolean =
  Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f

private fun Context.isActiveNetworkMetered(): Boolean =
  (getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager)?.isActiveNetworkMetered ?: true

private const val POSITION_POLL_MS = 50L
