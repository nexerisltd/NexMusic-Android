package com.nexapp.nexmusic.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import com.music.innertube.models.WatchEndpoint
import com.nexapp.nexmusic.LocalPlayerAwareWindowInsets
import com.nexapp.nexmusic.LocalPlayerConnection
import com.nexapp.nexmusic.R
import com.nexapp.nexmusic.constants.StatPeriod
import com.nexapp.nexmusic.extensions.toMediaItem
import com.nexapp.nexmusic.models.toMediaMetadata
import com.nexapp.nexmusic.playback.queues.ListQueue
import com.nexapp.nexmusic.playback.queues.YouTubeQueue
import com.nexapp.nexmusic.ui.component.ChoiceChipsRow
import com.nexapp.nexmusic.ui.component.HideOnScrollFAB
import com.nexapp.nexmusic.ui.component.IconButton
import com.nexapp.nexmusic.ui.component.LocalAlbumsGrid
import com.nexapp.nexmusic.ui.component.LocalArtistsGrid
import com.nexapp.nexmusic.ui.component.LocalMenuState
import com.nexapp.nexmusic.ui.component.LocalSongsGrid
import com.nexapp.nexmusic.ui.component.NavigationTitle
import com.nexapp.nexmusic.ui.menu.AlbumMenu
import com.nexapp.nexmusic.ui.menu.ArtistMenu
import com.nexapp.nexmusic.ui.menu.SongMenu
import com.nexapp.nexmusic.ui.utils.backToMain
import com.nexapp.nexmusic.utils.joinByBullet
import com.nexapp.nexmusic.utils.makeTimeString
import com.nexapp.nexmusic.viewmodels.StatsViewModel
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun StatsScreen(
  navController: NavController,
  viewModel: StatsViewModel = hiltViewModel(),
) {
  val menuState = LocalMenuState.current
  val haptic = LocalHapticFeedback.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
  val context = LocalContext.current

  val indexChips by viewModel.indexChips.collectAsState()
  val mostPlayedSongs by viewModel.mostPlayedSongs.collectAsState()
  val mostPlayedSongsStats by viewModel.mostPlayedSongsStats.collectAsState()
  val mostPlayedArtists by viewModel.mostPlayedArtists.collectAsState()
  val mostPlayedAlbums by viewModel.mostPlayedAlbums.collectAsState()
  val firstEvent by viewModel.firstEvent.collectAsState()
  val currentDate = LocalDateTime.now()

  val totalPlayTime by viewModel.totalPlayTime.collectAsState()
  val allTimePlayTime by viewModel.allTimePlayTime.collectAsState()
  val uniqueSongsCount by viewModel.uniqueSongsCount.collectAsState()
  val uniqueArtistsCount by viewModel.uniqueArtistsCount.collectAsState()
  val uniqueAlbumsCount by viewModel.uniqueAlbumsCount.collectAsState()

  var showHistorySheet by remember { mutableStateOf(false) }

  val coroutineScope = rememberCoroutineScope()
  val lazyListState = rememberLazyListState()
  val selectedOption by viewModel.selectedOption.collectAsState()

  val firstEventTimestamp = firstEvent?.event?.timestamp

  val weeklyDates =
    if (currentDate != null && firstEventTimestamp != null) {
      val minDate = firstEventTimestamp.minusWeeks(1)
      generateSequence(currentDate) { it.minusWeeks(1) }
        .takeWhile { it.isAfter(minDate) }
        .mapIndexed { index, date ->
          val endDate = date.plusWeeks(1).minusDays(1).coerceAtMost(currentDate)
          val formatter = DateTimeFormatter.ofPattern("dd MMM")

          val startDateFormatted = formatter.format(date)
          val endDateFormatted = formatter.format(endDate)

          val startMonth = date.month
          val endMonth = endDate.month
          val startYear = date.year
          val endYear = endDate.year

          val text =
            when {
              startYear != currentDate.year ->
                "$startDateFormatted, $startYear - $endDateFormatted, $endYear"
              startMonth != endMonth -> "$startDateFormatted - $endDateFormatted"
              else -> "${date.dayOfMonth} - $endDateFormatted"
            }
          Pair(index, text)
        }
        .toList()
    } else {
      emptyList()
    }

  val monthlyDates =
    if (currentDate != null && firstEventTimestamp != null) {
      val minDate = firstEventTimestamp.withDayOfMonth(1)
      generateSequence(currentDate.plusMonths(1).withDayOfMonth(1).minusDays(1)) {
          it.minusMonths(1)
        }
        .takeWhile {
          it.isAfter(minDate)
        }
        .mapIndexed { index, date ->
          val formatter = DateTimeFormatter.ofPattern("MMM")
          val formattedDate = formatter.format(date)
          val text =
            if (date.year != currentDate.year) {
              "$formattedDate ${date.year}"
            } else {
              formattedDate
            }
          Pair(index, text)
        }
        .toList()
    } else {
      emptyList()
    }

  val yearlyDates =
    if (currentDate != null && firstEventTimestamp != null) {
      generateSequence(
          currentDate.plusYears(1).withDayOfYear(1).minusDays(1),
        ) {
          it.minusYears(1)
        }
        .takeWhile {
          it.isAfter(firstEventTimestamp)
        }
        .mapIndexed { index, date -> Pair(index, "${date.year}") }
        .toList()
    } else {
      emptyList()
    }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      state = lazyListState,
      contentPadding =
        LocalPlayerAwareWindowInsets.current
          .only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom)
          .asPaddingValues(),
      modifier =
        Modifier.windowInsetsPadding(
          LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Top)
        )
    ) {
      item(key = "choice_chips") {
        ChoiceChipsRow(
          chips =
            when (selectedOption) {
              OptionStats.WEEKS -> weeklyDates
              OptionStats.MONTHS -> monthlyDates
              OptionStats.YEARS -> yearlyDates
              OptionStats.CONTINUOUS -> {
                listOf(
                  StatPeriod.WEEK_1.ordinal to pluralStringResource(R.plurals.n_week, 1, 1),
                  StatPeriod.MONTH_1.ordinal to pluralStringResource(R.plurals.n_month, 1, 1),
                  StatPeriod.MONTH_3.ordinal to pluralStringResource(R.plurals.n_month, 3, 3),
                  StatPeriod.MONTH_6.ordinal to pluralStringResource(R.plurals.n_month, 6, 6),
                  StatPeriod.YEAR_1.ordinal to pluralStringResource(R.plurals.n_year, 1, 1),
                  StatPeriod.ALL.ordinal to stringResource(R.string.filter_all),
                )
              }
            },
          options =
            listOf(
              OptionStats.CONTINUOUS to stringResource(id = R.string.continuous),
              OptionStats.WEEKS to stringResource(R.string.weeks),
              OptionStats.MONTHS to stringResource(R.string.months),
              OptionStats.YEARS to stringResource(R.string.years),
            ),
          selectedOption = selectedOption,
          onSelectionChange = {
            viewModel.selectedOption.value = it
            viewModel.indexChips.value = 0
          },
          currentValue = indexChips,
          onValueUpdate = { viewModel.indexChips.value = it },
        )
      }

      item(key = "mostPlayedSongs") {
        NavigationTitle(
          title = "${mostPlayedSongsStats.size} ${stringResource(id = R.string.songs)}",
          modifier = Modifier.animateItem(),
        )

        LazyRow(
          modifier = Modifier.animateItem(),
        ) {
          itemsIndexed(
            items = mostPlayedSongsStats,
            key = { _, song -> song.id },
          ) { index, song ->
            val playCount = song.songCountListened ?: 0
            LocalSongsGrid(
              title = "${index + 1}. ${song.title}",
              subtitle =
                joinByBullet(
                  pluralStringResource(
                    R.plurals.n_time,
                    playCount,
                    playCount,
                  ),
                  makeTimeString(song.timeListened),
                ),
              thumbnailUrl = song.thumbnailUrl,
              isActive = song.id == mediaMetadata?.id,
              isPlaying = isPlaying,
              forceCrop = true,
              modifier =
                Modifier.fillMaxWidth()
                  .combinedClickable(
                    onClick = {
                      if (song.id == mediaMetadata?.id) {
                        playerConnection.togglePlayPause()
                      } else {
                        val matchedSong =
                          mostPlayedSongs.find { it.id == song.id }
                            ?: mostPlayedSongs.getOrNull(index)
                        playerConnection.playQueue(
                          YouTubeQueue(
                            endpoint = WatchEndpoint(song.id),
                            preloadItem = matchedSong?.toMediaMetadata(),
                          ),
                        )
                      }
                    },
                    onLongClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      val matchedSong =
                        mostPlayedSongs.find { it.id == song.id }
                          ?: mostPlayedSongs.getOrNull(index)
                      if (matchedSong != null) {
                        menuState.show {
                          SongMenu(
                            originalSong = matchedSong,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      }
                    },
                  )
                  .animateItem(),
            )
          }
        }
      }

      item(key = "mostPlayedArtists") {
        NavigationTitle(
          title = "${mostPlayedArtists.size} ${stringResource(id = R.string.artists)}",
          modifier = Modifier.animateItem(),
        )

        LazyRow(
          modifier = Modifier.animateItem(),
        ) {
          itemsIndexed(
            items = mostPlayedArtists,
            key = { _, artist -> artist.id },
          ) { index, artist ->
            LocalArtistsGrid(
              title = "${index + 1}. ${artist.artist.name}",
              subtitle =
                joinByBullet(
                  pluralStringResource(R.plurals.n_time, artist.songCount, artist.songCount),
                  makeTimeString(artist.timeListened?.toLong()),
                ),
              thumbnailUrl = artist.artist.thumbnailUrl,
              forceCrop = true,
              modifier =
                Modifier.combinedClickable(
                    onClick = { navController.navigate("artist/${artist.id}") },
                    onLongClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      menuState.show {
                        ArtistMenu(
                          originalArtist = artist,
                          coroutineScope = coroutineScope,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    },
                  )
                  .animateItem(),
            )
          }
        }
      }

      item(key = "mostPlayedAlbums") {
        NavigationTitle(
          title = "${mostPlayedAlbums.size} ${stringResource(id = R.string.albums)}",
          modifier = Modifier.animateItem(),
        )

        if (mostPlayedAlbums.isNotEmpty()) {
          LazyRow(
            modifier = Modifier.animateItem(),
          ) {
            itemsIndexed(
              items = mostPlayedAlbums,
              key = { _, album -> album.id },
            ) { index, album ->
              val playCount = album.songCountListened ?: 0
              LocalAlbumsGrid(
                title = "${index + 1}. ${album.album.title}",
                subtitle =
                  joinByBullet(
                    pluralStringResource(
                      R.plurals.n_time,
                      playCount,
                      playCount,
                    ),
                    makeTimeString(album.timeListened),
                  ),
                thumbnailUrl = album.album.thumbnailUrl,
                isActive = album.id == mediaMetadata?.album?.id,
                isPlaying = isPlaying,
                forceCrop = true,
                modifier =
                  Modifier.fillMaxWidth()
                    .combinedClickable(
                      onClick = { navController.navigate("album/${album.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          AlbumMenu(
                            originalAlbum = album,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }
        }
      }
    }

    if (mostPlayedSongs.isNotEmpty()) {
      HideOnScrollFAB(
        visible = true,
        lazyListState = lazyListState,
        icon = R.drawable.shuffle,
        onClick = {
          playerConnection.playQueue(
            ListQueue(
              title = context.getString(R.string.most_played_songs),
              items = mostPlayedSongs.map { it.toMediaMetadata().toMediaItem() }.shuffled()
            )
          )
        }
      )
    }

    TopAppBar(
      title = { Text(stringResource(R.string.stats)) },
      navigationIcon = {
        IconButton(
          onClick = navController::navigateUp,
          onLongClick = navController::backToMain,
        ) {
          Icon(
            painterResource(R.drawable.arrow_back),
            contentDescription = null,
          )
        }
      },
      actions = {
        IconButton(onClick = { showHistorySheet = true }) {
          Icon(
            painter = painterResource(R.drawable.history),
            contentDescription = null,
          )
        }
      }
    )

    if (showHistorySheet) {
      val currentPeriodLabel =
        when (selectedOption) {
          OptionStats.WEEKS -> weeklyDates.getOrNull(indexChips)?.second.orEmpty()
          OptionStats.MONTHS -> monthlyDates.getOrNull(indexChips)?.second.orEmpty()
          OptionStats.YEARS -> yearlyDates.getOrNull(indexChips)?.second.orEmpty()
          OptionStats.CONTINUOUS -> {
            when (indexChips) {
              StatPeriod.WEEK_1.ordinal -> pluralStringResource(R.plurals.n_week, 1, 1)
              StatPeriod.MONTH_1.ordinal -> pluralStringResource(R.plurals.n_month, 1, 1)
              StatPeriod.MONTH_3.ordinal -> pluralStringResource(R.plurals.n_month, 3, 3)
              StatPeriod.MONTH_6.ordinal -> pluralStringResource(R.plurals.n_month, 6, 6)
              StatPeriod.YEAR_1.ordinal -> pluralStringResource(R.plurals.n_year, 1, 1)
              StatPeriod.ALL.ordinal -> stringResource(R.string.filter_all)
              else -> ""
            }
          }
        }

      ActivityHistoryBottomSheet(
        onDismiss = { showHistorySheet = false },
        totalPlayTimeMs = totalPlayTime,
        allTimePlayTimeMs = allTimePlayTime,
        uniqueSongs = uniqueSongsCount,
        uniqueArtists = uniqueArtistsCount,
        uniqueAlbums = uniqueAlbumsCount,
        periodLabel = currentPeriodLabel
      )
    }
  }
}
