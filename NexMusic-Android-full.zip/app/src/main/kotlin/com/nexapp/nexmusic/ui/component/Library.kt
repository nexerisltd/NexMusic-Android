package com.nexapp.nexmusic.ui.component

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavController
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.WatchEndpoint
import com.nexapp.nexmusic.R
import com.nexapp.nexmusic.db.entities.Album
import com.nexapp.nexmusic.db.entities.Artist
import com.nexapp.nexmusic.db.entities.Playlist
import com.nexapp.nexmusic.ui.menu.AlbumMenu
import com.nexapp.nexmusic.ui.menu.ArtistMenu
import com.nexapp.nexmusic.ui.menu.PlaylistMenu
import com.nexapp.nexmusic.ui.menu.YouTubePlaylistMenu
import com.nexapp.nexmusic.utils.libraryPlaylistRoute
import kotlinx.coroutines.CoroutineScope

@Composable
fun LibraryArtistListItem(
  navController: NavController,
  menuState: MenuState,
  coroutineScope: CoroutineScope,
  artist: Artist,
  modifier: Modifier = Modifier
) =
  ArtistListItem(
    artist = artist,
    trailingContent = {
      androidx.compose.material3.IconButton(
        onClick = {
          menuState.show {
            ArtistMenu(
              originalArtist = artist,
              coroutineScope = coroutineScope,
              onDismiss = menuState::dismiss
            )
          }
        }
      ) {
        Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
      }
    },
    modifier = modifier.fillMaxWidth().clickable { navController.navigate("artist/${artist.id}") }
  )

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryArtistGridItem(
  navController: NavController,
  menuState: MenuState,
  coroutineScope: CoroutineScope,
  artist: Artist,
  modifier: Modifier = Modifier
) =
  ArtistGridItem(
    artist = artist,
    fillMaxWidth = true,
    modifier =
      modifier
        .fillMaxWidth()
        .combinedClickable(
          onClick = { navController.navigate("artist/${artist.id}") },
          onLongClick = {
            menuState.show {
              ArtistMenu(
                originalArtist = artist,
                coroutineScope = coroutineScope,
                onDismiss = menuState::dismiss
              )
            }
          }
        )
  )

@Composable
fun LibraryAlbumListItem(
  modifier: Modifier = Modifier,
  navController: NavController,
  menuState: MenuState,
  album: Album,
  isActive: Boolean = false,
  isPlaying: Boolean = false
) =
  AlbumListItem(
    album = album,
    isActive = isActive,
    isPlaying = isPlaying,
    trailingContent = {
      androidx.compose.material3.IconButton(
        onClick = {
          menuState.show {
            AlbumMenu(
              originalAlbum = album,
              navController = navController,
              onDismiss = menuState::dismiss
            )
          }
        }
      ) {
        Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
      }
    },
    modifier = modifier.fillMaxWidth().clickable { navController.navigate("album/${album.id}") }
  )

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryAlbumGridItem(
  modifier: Modifier = Modifier,
  navController: NavController,
  menuState: MenuState,
  coroutineScope: CoroutineScope,
  album: Album,
  isActive: Boolean = false,
  isPlaying: Boolean = false
) =
  AlbumGridItem(
    album = album,
    isActive = isActive,
    isPlaying = isPlaying,
    coroutineScope = coroutineScope,
    fillMaxWidth = true,
    modifier =
      modifier
        .fillMaxWidth()
        .combinedClickable(
          onClick = { navController.navigate("album/${album.id}") },
          onLongClick = {
            menuState.show {
              AlbumMenu(
                originalAlbum = album,
                navController = navController,
                onDismiss = menuState::dismiss
              )
            }
          }
        )
  )

@Composable
fun LibraryPlaylistListItem(
  navController: NavController,
  menuState: MenuState,
  coroutineScope: CoroutineScope,
  playlist: Playlist,
  modifier: Modifier = Modifier
) =
  PlaylistListItem(
    playlist = playlist,
    trailingContent = {
      androidx.compose.material3.IconButton(
        onClick = {
          menuState.show {
            if (playlist.playlist.isEditable || playlist.songCount != 0) {
              PlaylistMenu(
                playlist = playlist,
                coroutineScope = coroutineScope,
                onDismiss = menuState::dismiss
              )
            } else {
              playlist.playlist.browseId?.let { browseId ->
                YouTubePlaylistMenu(
                  playlist =
                    PlaylistItem(
                      id = browseId,
                      title = playlist.playlist.name,
                      author = null,
                      songCountText = null,
                      thumbnail = playlist.thumbnails.getOrNull(0) ?: "",
                      playEndpoint =
                        WatchEndpoint(
                          playlistId = browseId,
                          params = playlist.playlist.playEndpointParams
                        ),
                      shuffleEndpoint =
                        WatchEndpoint(
                          playlistId = browseId,
                          params = playlist.playlist.shuffleEndpointParams
                        ),
                      radioEndpoint =
                        WatchEndpoint(
                          playlistId = "RDAMPL$browseId",
                          params = playlist.playlist.radioEndpointParams
                        ),
                      isEditable = false
                    ),
                  coroutineScope = coroutineScope,
                  onDismiss = menuState::dismiss
                )
              }
            }
          }
        }
      ) {
        Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
      }
    },
    modifier =
      modifier.fillMaxWidth().clickable {
        navController.navigate(
          libraryPlaylistRoute(
            localPlaylistId = playlist.id,
            browseId = playlist.playlist.browseId,
            isEditable = playlist.playlist.isEditable,
            songCount = playlist.songCount,
            remoteSongCount = playlist.playlist.remoteSongCount,
          )
        )
      }
  )

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryPlaylistGridItem(
  navController: NavController,
  menuState: MenuState,
  coroutineScope: CoroutineScope,
  playlist: Playlist,
  modifier: Modifier = Modifier
) =
  PlaylistGridItem(
    playlist = playlist,
    fillMaxWidth = true,
    modifier =
      modifier
        .fillMaxWidth()
        .combinedClickable(
          onClick = {
            navController.navigate(
              libraryPlaylistRoute(
                localPlaylistId = playlist.id,
                browseId = playlist.playlist.browseId,
                isEditable = playlist.playlist.isEditable,
                songCount = playlist.songCount,
                remoteSongCount = playlist.playlist.remoteSongCount,
              )
            )
          },
          onLongClick = {
            menuState.show {
              if (playlist.playlist.isEditable || playlist.songCount != 0) {
                PlaylistMenu(
                  playlist = playlist,
                  coroutineScope = coroutineScope,
                  onDismiss = menuState::dismiss
                )
              } else {
                playlist.playlist.browseId?.let { browseId ->
                  YouTubePlaylistMenu(
                    playlist =
                      PlaylistItem(
                        id = browseId,
                        title = playlist.playlist.name,
                        author = null,
                        songCountText = null,
                        thumbnail = playlist.thumbnails.getOrNull(0) ?: "",
                        playEndpoint =
                          WatchEndpoint(
                            playlistId = browseId,
                            params = playlist.playlist.playEndpointParams
                          ),
                        shuffleEndpoint =
                          WatchEndpoint(
                            playlistId = browseId,
                            params = playlist.playlist.shuffleEndpointParams
                          ),
                        radioEndpoint =
                          WatchEndpoint(
                            playlistId = "RDAMPL$browseId",
                            params = playlist.playlist.radioEndpointParams
                          ),
                        isEditable = false
                      ),
                    coroutineScope = coroutineScope,
                    onDismiss = menuState::dismiss
                  )
                }
              }
            }
          }
        )
  )
