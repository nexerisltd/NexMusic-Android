package com.nexapp.nexmusic.ui.component.shimmer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.nexapp.nexmusic.constants.GridItemSize
import com.nexapp.nexmusic.constants.GridItemsSizeKey
import com.nexapp.nexmusic.constants.GridThumbnailHeight
import com.nexapp.nexmusic.constants.SmallGridThumbnailHeight
import com.nexapp.nexmusic.constants.ThumbnailCornerRadius
import com.nexapp.nexmusic.utils.rememberEnumPreference

@Composable
fun GridItemPlaceHolder(
  modifier: Modifier = Modifier,
  thumbnailShape: Shape = RoundedCornerShape(ThumbnailCornerRadius),
  fillMaxWidth: Boolean = false,
) {
  val gridItemSize by rememberEnumPreference(GridItemsSizeKey, GridItemSize.BIG)
  val gridHeight =
    if (gridItemSize == GridItemSize.BIG) GridThumbnailHeight else SmallGridThumbnailHeight

  Column(
    modifier =
      if (fillMaxWidth) {
        modifier.padding(12.dp).fillMaxWidth()
      } else {
        modifier.padding(12.dp).width(gridHeight)
      },
  ) {
    Spacer(
      modifier =
        if (fillMaxWidth) {
            Modifier.fillMaxWidth()
          } else {
            Modifier.height(gridHeight)
          }
          .aspectRatio(1f)
          .clip(thumbnailShape)
          .background(MaterialTheme.colorScheme.surfaceVariant),
    )

    Spacer(modifier = Modifier.height(6.dp))

    TextPlaceholder()

    TextPlaceholder()
  }
}
