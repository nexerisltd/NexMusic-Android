package com.nexapp.nexmusic.ui.screens

import android.app.Activity
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.dialog
import androidx.navigation.navArgument
import com.nexapp.nexmusic.constants.DarkModeKey
import com.nexapp.nexmusic.constants.PureBlackKey
import com.nexapp.nexmusic.nexmusic.changelog.ChangelogScreen
import com.nexapp.nexmusic.nexmusic.commitscreen.CommitScreen
import com.nexapp.nexmusic.nexmusic.updater.UpdateScreen
import com.nexapp.nexmusic.ui.screens.ambient.AmbientModeScreen
import com.nexapp.nexmusic.ui.screens.artist.ArtistAlbumsScreen
import com.nexapp.nexmusic.ui.screens.artist.ArtistItemsScreen
import com.nexapp.nexmusic.ui.screens.artist.ArtistScreen
import com.nexapp.nexmusic.ui.screens.artist.ArtistSongsScreen
import com.nexapp.nexmusic.ui.screens.equalizer.EqScreen
import com.nexapp.nexmusic.ui.screens.equalizer.axion.AxionEqScreen
import com.nexapp.nexmusic.ui.screens.generate.GenerateScreen
import com.nexapp.nexmusic.ui.screens.library.LibraryScreen
import com.nexapp.nexmusic.ui.screens.library.LocalSongScreen
import com.nexapp.nexmusic.ui.screens.musicflow.MusicFlowScreen
import com.nexapp.nexmusic.ui.screens.playlist.AutoPlaylistScreen
import com.nexapp.nexmusic.ui.screens.playlist.BottomPlaylistScreen
import com.nexapp.nexmusic.ui.screens.playlist.CachePlaylistScreen
import com.nexapp.nexmusic.ui.screens.playlist.LocalPlaylistScreen
import com.nexapp.nexmusic.ui.screens.playlist.OnlinePlaylistScreen
import com.nexapp.nexmusic.ui.screens.playlist.TopPlaylistScreen
import com.nexapp.nexmusic.ui.screens.recognition.RecognitionHistoryScreen
import com.nexapp.nexmusic.ui.screens.recognition.RecognitionScreen
import com.nexapp.nexmusic.ui.screens.search.OnlineSearchResult
import com.nexapp.nexmusic.ui.screens.search.SearchScreen
import com.nexapp.nexmusic.ui.screens.settings.AboutScreen
import com.nexapp.nexmusic.ui.screens.settings.AccountSettingsScreen
import com.nexapp.nexmusic.ui.screens.settings.AiSettings
import com.nexapp.nexmusic.ui.screens.settings.AppIconSettingsScreen
import com.nexapp.nexmusic.ui.screens.settings.AppearanceSettings
import com.nexapp.nexmusic.ui.screens.settings.BackupAndRestore
import com.nexapp.nexmusic.ui.screens.settings.BlockedArtistsScreen
import com.nexapp.nexmusic.ui.screens.settings.ContentSettings
import com.nexapp.nexmusic.ui.screens.settings.DarkMode
import com.nexapp.nexmusic.ui.screens.settings.GlassEffectSettings
import com.nexapp.nexmusic.ui.screens.settings.MusicFlowSettings
import com.nexapp.nexmusic.ui.screens.settings.PlayerSettings
import com.nexapp.nexmusic.ui.screens.settings.PrivacySettings
import com.nexapp.nexmusic.ui.screens.settings.SettingsScreen
import com.nexapp.nexmusic.ui.screens.settings.StorageSettings
import com.nexapp.nexmusic.ui.screens.settings.ThemeScreen
import com.nexapp.nexmusic.ui.screens.settings.UpdateSettings
import com.nexapp.nexmusic.ui.screens.settings.UptimeScreen
import com.nexapp.nexmusic.ui.screens.settings.integrations.ListenTogetherSettings
import com.nexapp.nexmusic.utils.rememberEnumPreference
import com.nexapp.nexmusic.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.navigationBuilder(
  navController: NavHostController,
  scrollBehavior: TopAppBarScrollBehavior,
  activity: Activity,
  snackbarHostState: SnackbarHostState
) {
  composable(Screens.Home.route) {
    HomeScreen(navController = navController, snackbarHostState = snackbarHostState)
  }

  composable(Screens.Search.route) {
    val pureBlackEnabled by rememberPreference(PureBlackKey, defaultValue = false)
    val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
    val isSystemInDarkTheme = isSystemInDarkTheme()
    val useDarkTheme =
      remember(darkTheme, isSystemInDarkTheme) {
        if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
      }
    val pureBlack = remember(pureBlackEnabled, useDarkTheme) { pureBlackEnabled && useDarkTheme }
    SearchScreen(navController = navController, pureBlack = pureBlack)
  }

  composable(Screens.Library.route) { LibraryScreen(navController) }

  composable(Screens.ListenTogether.route) {
    ListenTogetherScreen(navController, showTopBar = false)
  }

  composable(
    route = "listen_together_from_topbar",
  ) {
    ListenTogetherScreen(navController, showTopBar = true)
  }

  composable("listen_together/chat") { CommentTogetherScreen(navController) }

  composable("history") { HistoryScreen(navController) }

  composable("ambient_mode") { AmbientModeScreen(navController) }

  composable("music_flow") { MusicFlowScreen(navController) }

  composable("local_songs") { LocalSongScreen(navController) }

  composable("stats") { StatsScreen(navController) }

  composable("mood_and_genres") { MoodAndGenresScreen(navController, scrollBehavior) }

  composable("account") { AccountScreen(navController, scrollBehavior) }

  composable("new_release") { NewReleaseScreen(navController, scrollBehavior) }

  composable("charts_screen") { ChartsScreen(navController) }

  composable(
    route = "browse/{browseId}",
    arguments = listOf(navArgument("browseId") { type = NavType.StringType })
  ) {
    BrowseScreen(navController, scrollBehavior, it.arguments?.getString("browseId"))
  }

  composable(
    route = "search/{query}",
    arguments =
      listOf(
        navArgument("query") { type = NavType.StringType },
      ),
    enterTransition = { fadeIn(tween(250)) },
    exitTransition = {
      if (targetState.destination.route?.startsWith("search/") == true) {
        fadeOut(tween(200))
      } else {
        fadeOut(tween(200)) + slideOutHorizontally { -it / 2 }
      }
    },
    popEnterTransition = {
      if (initialState.destination.route?.startsWith("search/") == true) {
        fadeIn(tween(250))
      } else {
        fadeIn(tween(250)) + slideInHorizontally { -it / 2 }
      }
    },
    popExitTransition = { fadeOut(tween(200)) },
  ) {
    OnlineSearchResult(navController)
  }

  composable(
    route = "album/{albumId}",
    arguments =
      listOf(
        navArgument("albumId") { type = NavType.StringType },
      ),
  ) {
    AlbumScreen(navController, scrollBehavior)
  }

  composable(
    route = "artist/{artistId}",
    arguments =
      listOf(
        navArgument("artistId") { type = NavType.StringType },
      ),
  ) {
    ArtistScreen(navController, scrollBehavior)
  }

  composable(
    route = "artist/{artistId}/songs",
    arguments =
      listOf(
        navArgument("artistId") { type = NavType.StringType },
      ),
  ) {
    ArtistSongsScreen(navController, scrollBehavior)
  }

  composable(
    route = "artist/{artistId}/albums",
    arguments = listOf(navArgument("artistId") { type = NavType.StringType })
  ) {
    ArtistAlbumsScreen(navController, scrollBehavior)
  }

  composable(
    route = "artist/{artistId}/items?browseId={browseId}?params={params}",
    arguments =
      listOf(
        navArgument("artistId") { type = NavType.StringType },
        navArgument("browseId") {
          type = NavType.StringType
          nullable = true
        },
        navArgument("params") {
          type = NavType.StringType
          nullable = true
        },
      ),
  ) {
    ArtistItemsScreen(navController, scrollBehavior)
  }

  composable(
    route = "online_playlist/{playlistId}",
    arguments =
      listOf(
        navArgument("playlistId") { type = NavType.StringType },
      ),
  ) {
    OnlinePlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "local_playlist/{playlistId}",
    arguments =
      listOf(
        navArgument("playlistId") { type = NavType.StringType },
      ),
  ) {
    LocalPlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "auto_playlist/{playlist}",
    arguments =
      listOf(
        navArgument("playlist") { type = NavType.StringType },
      ),
  ) {
    AutoPlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "cache_playlist/{playlist}",
    arguments =
      listOf(
        navArgument("playlist") { type = NavType.StringType },
      ),
  ) {
    CachePlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "top_playlist/{top}",
    arguments =
      listOf(
        navArgument("top") { type = NavType.StringType },
      ),
  ) {
    TopPlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "bottom_playlist/{bottom}",
    arguments =
      listOf(
        navArgument("bottom") { type = NavType.StringType },
      ),
  ) {
    BottomPlaylistScreen(navController, scrollBehavior)
  }

  composable(
    route = "youtube_browse/{browseId}?params={params}",
    arguments =
      listOf(
        navArgument("browseId") {
          type = NavType.StringType
          nullable = true
        },
        navArgument("params") {
          type = NavType.StringType
          nullable = true
        },
      ),
  ) {
    YouTubeBrowseScreen(navController)
  }

  composable("settings") { SettingsScreen(navController, scrollBehavior) }
  composable("blocked_artists") { BlockedArtistsScreen(navController) }

  composable(
    route = "settings/update?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    UpdateSettings(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable(
    route = "settings/account?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    AccountSettingsScreen(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("ambient_settings") {
    com.nexapp.nexmusic.ui.screens.settings.AmbientSettingsScreen(navController)
  }

  composable(
    route = "settings/appearance?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    AppearanceSettings(
      navController,
      scrollBehavior,
      activity,
      snackbarHostState,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("settings/appearance/theme") { ThemeScreen(navController) }
  composable("settings/music_flow") { MusicFlowSettings(navController, scrollBehavior) }
  composable(
    route = "settings/appearance/haptics?highlightKey={highlightKey}",
    arguments = listOf(navArgument("highlightKey") { type = NavType.StringType; nullable = true })
  ) { backStackEntry ->
    com.nexapp.nexmusic.ui.screens.settings.HapticsSettings(
      navController = navController,
      scrollBehavior = scrollBehavior,
      activity = activity,
      snackbarHostState = snackbarHostState,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("settings/appearance/app_icon") {
    AppIconSettingsScreen(navController, activity, snackbarHostState)
  }

  composable("settings/appearance/font") {
    com.nexapp.nexmusic.ui.screens.settings.FontSelectionScreen(navController, scrollBehavior)
  }

  composable("settings/listening_summary") {
    com.nexapp.nexmusic.ui.screens.ListeningSummaryScreen(navController)
  }

  composable(
    route = "detailed_listening_history/{startTimestamp}",
    arguments =
      listOf(
        navArgument("startTimestamp") { type = NavType.StringType },
      ),
  ) {
    com.nexapp.nexmusic.ui.screens.DetailedListeningHistoryScreen(navController)
  }

  composable("settings/appearance/liquidglass") {
    GlassEffectSettings(navController, scrollBehavior)
  }

  composable(
    route = "settings/content?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    ContentSettings(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("uptime") { UptimeScreen(navController, scrollBehavior) }

  composable(
    route = "settings/ai?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    AiSettings(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable(
    route = "settings/player?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    PlayerSettings(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable(
    route =
      "settings/storage?autoOpenExportPicker={autoOpenExportPicker}&highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("autoOpenExportPicker") {
          type = NavType.BoolType
          defaultValue = false
        },
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    val autoOpenExportPicker = backStackEntry.arguments?.getBoolean("autoOpenExportPicker") ?: false
    StorageSettings(
      navController = navController,
      scrollBehavior = scrollBehavior,
      autoOpenExportPicker = autoOpenExportPicker,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("settings/equalizer") { AxionEqScreen(onBackClick = { navController.navigateUp() }) }

  composable(
    route = "settings/privacy?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    PrivacySettings(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable(
    route = "settings/backup_restore?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    BackupAndRestore(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("settings/extensions") {
    com.nexapp.nexmusic.ui.screens.settings.ExtensionSettingsScreen(
        navController = navController,
        scrollBehavior = scrollBehavior
    )
  }
  composable("settings/discord") {
    com.nexapp.nexmusic.ui.screens.settings.DiscordSettings(navController, scrollBehavior)
  }

  composable("settings/lastfm") {
    com.nexapp.nexmusic.ui.screens.settings.LastFMSettingsScreen(navController)
  }

  composable("settings/discord/experimental") {
    com.nexapp.nexmusic.ui.screens.settings.DiscordExperimental(navController)
  }

  composable("settings/spotify_import") { SpotifyImportScreen(navController) }

  composable(route = "settings/integrations/listen_together") {
    ListenTogetherSettings(navController, scrollBehavior)
  }

  composable(
    route = "settings/about?highlightKey={highlightKey}",
    arguments =
      listOf(
        navArgument("highlightKey") {
          type = NavType.StringType
          nullable = true
        }
      )
  ) { backStackEntry ->
    AboutScreen(
      navController,
      scrollBehavior,
      highlightKey = backStackEntry.arguments?.getString("highlightKey")
    )
  }

  composable("update") { UpdateScreen(navController) }

  composable("login") { LoginScreen(navController) }

  dialog("equalizer") { EqScreen(navController = navController) }

  composable("recognition") { RecognitionScreen(navController) }

  composable("recognition_history") { RecognitionHistoryScreen(navController) }
  composable("settings/changelog") { ChangelogScreen(navController, scrollBehavior) }
  composable("settings/commits") { CommitScreen(navController, scrollBehavior) }
  composable("generate") { GenerateScreen(navController) }
}
