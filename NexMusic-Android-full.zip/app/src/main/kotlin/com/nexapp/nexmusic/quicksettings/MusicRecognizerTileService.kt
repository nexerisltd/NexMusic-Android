package com.nexapp.nexmusic.quicksettings

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.nexapp.nexmusic.R
import com.nexapp.nexmusic.recognition.RecognitionLaunchActivity

class MusicRecognizerTileService : TileService() {
  override fun onStartListening() {
    super.onStartListening()
    qsTile?.apply {
      icon = Icon.createWithResource(this@MusicRecognizerTileService, R.drawable.mic)
      state = Tile.STATE_INACTIVE
      updateTile()
    }
  }

  override fun onClick() {
    super.onClick()
    val launchIntent =
      Intent(this, RecognitionLaunchActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION
      }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      val pendingIntent =
        PendingIntent.getActivity(
          this,
          0,
          launchIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
      startActivityAndCollapse(pendingIntent)
    } else {
      @Suppress("DEPRECATION") startActivityAndCollapse(launchIntent)
    }
  }
}
