package com.nexapp.nexmusic.playback

import android.content.Context
import android.net.ConnectivityManager
import androidx.core.content.getSystemService
import androidx.media3.database.DatabaseProvider
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.scheduler.Requirements
import coil3.SingletonImageLoader
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import com.music.innertube.YouTube
import com.music.innertube.models.IpVersion
import dagger.hilt.android.qualifiers.ApplicationContext
import com.nexapp.nexmusic.constants.AudioQuality
import com.nexapp.nexmusic.constants.DownloadOnWifiOnlyKey
import com.nexapp.nexmusic.constants.DownloadQuality
import com.nexapp.nexmusic.constants.DownloadQualityKey
import com.nexapp.nexmusic.constants.DownloadWithMetadataKey
import com.nexapp.nexmusic.constants.IpVersionKey
import com.nexapp.nexmusic.db.MusicDatabase
import com.nexapp.nexmusic.db.entities.FormatEntity
import com.nexapp.nexmusic.db.entities.LyricsEntity
import com.nexapp.nexmusic.db.entities.SongEntity
import com.nexapp.nexmusic.di.DownloadCache
import com.nexapp.nexmusic.di.PlayerCache
import com.nexapp.nexmusic.lyrics.LyricsProviderRegistry
import com.nexapp.nexmusic.lyrics.LyricsUtils
import com.nexapp.nexmusic.ui.utils.resize
import com.nexapp.nexmusic.utils.YTPlayerUtils
import com.nexapp.nexmusic.utils.dataStore
import com.nexapp.nexmusic.utils.enumPreference
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.Dns
import okhttp3.OkHttpClient

@Singleton
class DownloadUtil
@Inject
constructor(
  @ApplicationContext context: Context,
  val database: MusicDatabase,
  val databaseProvider: DatabaseProvider,
  @DownloadCache val downloadCache: SimpleCache,
  @PlayerCache val playerCache: SimpleCache,
) {
  private val connectivityManager = context.getSystemService<ConnectivityManager>()!!
  private val downloadQuality by
    enumPreference(
      context,
      DownloadQualityKey,
      DownloadQuality.YOUTUBE
    )
  private val ipVersion by enumPreference(context, IpVersionKey, IpVersion.AUTO)
  private val songUrlCache = ConcurrentHashMap<String, ResolvedStream>()

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  val downloads = MutableStateFlow<Map<String, Download>>(emptyMap())

  private val dataSourceFactory: androidx.media3.datasource.DataSource.Factory =
    ResolvingDataSource.Factory(
      ChunkingDataSourceFactory(
        // Read already-streamed bytes from playerCache instead of re-downloading them:
        // a song played before being downloaded would otherwise be fetched twice.
        CacheDataSource.Factory()
          .setCache(playerCache)
          .setUpstreamDataSourceFactory(
            OkHttpDataSource.Factory(
              OkHttpClient.Builder()
                .dns(
                  object : Dns {
                    override fun lookup(hostname: String): List<InetAddress> {
                      val addresses = Dns.SYSTEM.lookup(hostname)
                      return when (this@DownloadUtil.ipVersion) {
                        IpVersion.IPV4 ->
                          addresses.filter { it is Inet4Address }.ifEmpty { addresses }
                        IpVersion.IPV6 ->
                          addresses.filter { it is Inet6Address }.ifEmpty { addresses }
                        IpVersion.AUTO -> addresses
                      }
                    }
                  }
                )
                .proxy(YouTube.proxy)
                .proxyAuthenticator { _, response ->
                  YouTube.proxyAuth?.let { auth ->
                    response.request.newBuilder().header("Proxy-Authorization", auth).build()
                  } ?: response.request
                }
                .build(),
            )
          )
          .setCacheWriteDataSinkFactory(null)
          .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
      )
    ) { dataSpec ->
      // If this is a Canvas request (e.g., Apple Music or Tidal), bypass YouTube resolution!
      if (
        dataSpec.uri.toString().contains("apple.com") ||
          dataSpec.uri.toString().contains("music.apple") ||
          dataSpec.uri.toString().contains(".m3u8") ||
          dataSpec.uri.toString().contains(".mp4") ||
          dataSpec.key?.endsWith("_canvas") == true
      ) {
        return@Factory dataSpec
      }

      val mediaId = dataSpec.key ?: error("No media id")

      songUrlCache["${mediaId}_${downloadQuality.name}"]
        ?.takeIf { it.expiresAtMs > System.currentTimeMillis() }
        ?.let {
          return@Factory it.resolve(dataSpec)
        }

      val playbackData =
        runBlocking(Dispatchers.IO) {
            YTPlayerUtils.playerResponseForPlayback(
              videoId = mediaId,
              audioQuality = AudioQuality.OPUS,
              connectivityManager = connectivityManager
            )
          }
          .getOrThrow()
      val format = playbackData.format

      database.query {
        upsert(
          FormatEntity(
            id = mediaId,
            itag = format.itag,
            mimeType = format.mimeType.split(";")[0],
            codecs =
              format.mimeType.split("codecs=").getOrNull(1)?.removeSurrounding("\"") ?: "opus",
            bitrate = format.bitrate,
            sampleRate = format.audioSampleRate,
            contentLength = format.contentLength ?: 0L,
            loudnessDb = playbackData.audioConfig?.loudnessDb,
            perceptualLoudnessDb = playbackData.audioConfig?.perceptualLoudnessDb,
            playbackUrl = playbackData.playbackTracking?.videostatsPlaybackUrl?.baseUrl
          ),
        )

        val now = LocalDateTime.now()
        val existingSongInfo = getSongByIdBlocking(mediaId)
        val existing = existingSongInfo?.song

        val downloadMetadata = runBlocking {
          context.dataStore.data.first()[DownloadWithMetadataKey] ?: true
        }
        if (downloadMetadata) {
          scope.launch(Dispatchers.IO) {
            try {
              val title = existingSongInfo?.title ?: playbackData.videoDetails?.title ?: ""
              val artist =
                existingSongInfo?.artists?.joinToString { it.name }
                  ?: playbackData.videoDetails?.author
                  ?: ""
              val albumName = existingSongInfo?.album?.title ?: title
              val duration = playbackData.videoDetails?.lengthSeconds?.toIntOrNull() ?: 0

              // 2. Fetch Lyrics
              val providers =
                LyricsProviderRegistry.getDefaultProviderOrder().mapNotNull {
                  LyricsProviderRegistry.getProviderByName(it)
                }
              var foundLyrics: String? = null
              var foundProvider: String? = null

              for (provider in providers) {
                if (!provider.isEnabled(context)) continue
                val res = provider.getLyrics(mediaId, title, artist, duration, null).getOrNull()
                if (res != null && res != LyricsEntity.LYRICS_NOT_FOUND && res.isNotBlank()) {
                  foundLyrics = res
                  foundProvider = provider.name
                  if (LyricsUtils.hasSyncedLyrics(res)) {
                    break // Synced lyrics, stop searching
                  }
                }
              }
              if (foundLyrics != null && foundProvider != null) {
                database.query {
                  upsert(LyricsEntity(id = mediaId, lyrics = foundLyrics, provider = foundProvider))
                }
              }
            } catch (e: Exception) {
              e.printStackTrace()
            }
          }
        }

        val updatedSong =
          if (existing != null) {
            existing.copy(
              dateDownload = existing.dateDownload ?: now,
              thumbnailUrl =
                existing.thumbnailUrl
                  ?: playbackData.videoDetails
                    ?.thumbnail
                    ?.thumbnails
                    ?.lastOrNull()
                    ?.url
                    ?.resize(1200, 1200)
            )
          } else {
            SongEntity(
              id = mediaId,
              title = playbackData.videoDetails?.title ?: "Unknown",
              duration = playbackData.videoDetails?.lengthSeconds?.toIntOrNull() ?: 0,
              thumbnailUrl =
                playbackData.videoDetails
                  ?.thumbnail
                  ?.thumbnails
                  ?.lastOrNull()
                  ?.url
                  ?.resize(1200, 1200),
              dateDownload = now,
              isDownloaded = false
            )
          }

        upsert(updatedSong)

        updatedSong.thumbnailUrl?.let { url ->
          val request =
            ImageRequest.Builder(context)
              .data(url)
              .memoryCachePolicy(CachePolicy.ENABLED)
              .diskCachePolicy(CachePolicy.ENABLED)
              .build()
          SingletonImageLoader.get(context).enqueue(request)
        }
      }

      val stream = ResolvedStream.from(playbackData)
      songUrlCache["${mediaId}_${downloadQuality.name}"] = stream
      stream.resolve(dataSpec)
    }

  val downloadNotificationHelper =
    DownloadNotificationHelper(context, ExoDownloadService.CHANNEL_ID)

  @OptIn(DelicateCoroutinesApi::class)
  val downloadManager: DownloadManager =
    DownloadManager(
        context,
        databaseProvider,
        downloadCache,
        dataSourceFactory,
        Executors.newFixedThreadPool(3)
      )
      .apply {
        maxParallelDownloads = 3
        addListener(
          object : DownloadManager.Listener {
            override fun onDownloadChanged(
              downloadManager: DownloadManager,
              download: Download,
              finalException: Exception?,
            ) {
              downloads.update { map ->
                map.toMutableMap().apply { set(download.request.id, download) }
              }

              scope.launch {
                when (download.state) {
                  Download.STATE_COMPLETED -> {
                    val timestamp = if (download.updateTimeMs > 0) download.updateTimeMs else System.currentTimeMillis()
                    val downloadDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneOffset.UTC)
                    database.updateDownloadedInfo(download.request.id, true, downloadDate)
                  }
                  Download.STATE_FAILED,
                  Download.STATE_STOPPED,
                  Download.STATE_REMOVING -> {
                    database.updateDownloadedInfo(download.request.id, false, null)
                  }
                  else -> {}
                }
              }
            }
          }
        )
      }

  init {
    val result = mutableMapOf<String, Download>()
    downloadManager.downloadIndex.getDownloads().use { cursor ->
      while (cursor.moveToNext()) {
        result[cursor.download.request.id] = cursor.download
      }
    }
    downloads.value = result

    scope.launch(Dispatchers.IO) {
      result.values.forEach { download ->
        if (download.state == Download.STATE_COMPLETED) {
          val timestamp = if (download.updateTimeMs > 0) download.updateTimeMs else System.currentTimeMillis()
          val downloadDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneOffset.UTC)
          database.updateDownloadedInfo(download.request.id, true, downloadDate)
        }
      }
    }

    // Wi-Fi-only downloads: DownloadManager pauses queued downloads whenever the
    // active requirements aren't met, so flipping this pref mid-download stops it
    // on mobile data without losing progress.
    scope.launch {
      context.dataStore.data
        .map { it[DownloadOnWifiOnlyKey] ?: false }
        .distinctUntilChanged()
        .collectLatest { wifiOnly ->
          downloadManager.requirements =
            Requirements(if (wifiOnly) Requirements.NETWORK_UNMETERED else Requirements.NETWORK)
        }
    }
  }

  fun getDownload(songId: String): Flow<Download?> = downloads.map { it[songId] }

  fun release() {
    scope.cancel()
  }
}
