package com.nexapp.nexmusic.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.nexapp.nexmusic.R

val bbhBartle = FontFamily(Font(R.font.bbh_bartle_regular, FontWeight.Normal))
