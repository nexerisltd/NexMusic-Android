package com.nexapp.nexmusic.lyrics

import android.content.Context
import com.music.innertube.YouTube
import com.music.innertube.models.WatchEndpoint

object YouTubeLyricsProvider : LyricsProvider {
  override val name = "YouTube Music"

  override fun isEnabled(context: Context) = true

  override suspend fun getLyrics(
    id: String,
    title: String,
    artist: String,
    duration: Int,
    album: String?,
  ): Result<String> = runCatching {
    val nextResult = YouTube.next(WatchEndpoint(videoId = id)).getOrThrow()
    YouTube.lyrics(
        endpoint =
          nextResult.lyricsEndpoint ?: throw IllegalStateException("Lyrics endpoint not found"),
      )
      .getOrThrow() ?: throw IllegalStateException("Lyrics unavailable")
  }
}
