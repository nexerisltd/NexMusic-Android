package com.nexapp.nexmusic.lyrics

import android.content.Context
import com.nexapp.nexmusic.lyrics.R
import com.nexapp.nexmusic.api.DeepLService
import com.nexapp.nexmusic.api.MistralService
import com.nexapp.nexmusic.api.OpenRouterService
import com.nexapp.nexmusic.api.OpenRouterStreamingService
import com.nexapp.nexmusic.constants.LanguageCodeToName
import com.nexapp.nexmusic.db.MusicDatabase
import com.nexapp.nexmusic.db.entities.LyricsEntity
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import com.nexapp.nexmusic.ai.AiLogger

object LyricsTranslationHelper {
  private val _status = MutableStateFlow<TranslationStatus>(TranslationStatus.Idle)
  val status: StateFlow<TranslationStatus> = _status.asStateFlow()

  private val _hasActiveTranslations = MutableStateFlow(false)
  val hasActiveTranslations: StateFlow<Boolean> = _hasActiveTranslations.asStateFlow()

  private val _manualTrigger =
    MutableSharedFlow<Unit>(
      extraBufferCapacity = 1,
      onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
    )
  val manualTrigger: SharedFlow<Unit> = _manualTrigger.asSharedFlow()

  private val _clearTranslationsTrigger =
    MutableSharedFlow<Unit>(
      extraBufferCapacity = 1,
      onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
    )
  val clearTranslationsTrigger: SharedFlow<Unit> = _clearTranslationsTrigger.asSharedFlow()

  private val _translationSaved =
    MutableSharedFlow<Unit>(
      extraBufferCapacity = 1,
      onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
    )
  val translationSaved: SharedFlow<Unit> = _translationSaved.asSharedFlow()

  private var translationJob: Job? = null
  private var statusResetJob: Job? = null
  private var isCompositionActive = true

  private val translationCache = mutableMapOf<String, List<String>>()

  private fun getCacheKey(lyricsText: String, mode: String, language: String): String =
    "${lyricsText.hashCode()}_${mode}_$language"

  private fun tryParsePartialTranslation(content: String, expectedCount: Int): List<String> {
    val startIdx = content.indexOf('[')
    if (startIdx == -1) return emptyList()

    val result = mutableListOf<String>()
    var pos = startIdx + 1
    var inString = false
    var escaping = false
    val currentString = StringBuilder()

    while (pos < content.length && result.size < expectedCount) {
      val char = content[pos]

      when {
        escaping -> {
          currentString.append(char)
          escaping = false
        }
        char == '\\' && inString -> {
          currentString.append(char)
          escaping = true
        }
        char == '"' -> {
          if (inString) {
            result.add(currentString.toString())
            currentString.clear()
            inString = false
          } else {
            inString = true
          }
        }
        inString -> {
          currentString.append(char)
        }
        char == ']' -> {
          break
        }
      }
      pos++
    }

    return result
  }

  fun getCachedTranslations(
    lyrics: List<LyricsEntry>,
    mode: String,
    language: String
  ): List<String>? {
    val lyricsText = lyrics.filter { it.text.isNotBlank() }.joinToString("\n") { it.text }
    val key = getCacheKey(lyricsText, mode, language)
    return translationCache[key]
  }

  fun applyCachedTranslations(lyrics: List<LyricsEntry>, mode: String, language: String): Boolean {
    val cached = getCachedTranslations(lyrics, mode, language) ?: return false
    val nonEmptyEntries =
      lyrics.mapIndexedNotNull { index, entry ->
        if (entry.text.isNotBlank()) index to entry else null
      }

    if (cached.size >= nonEmptyEntries.size) {
      nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
        lyrics[originalIndex].translatedTextFlow.value = cached[idx]
      }
      return true
    }
    return false
  }

  fun triggerManualTranslation() {
    _manualTrigger.tryEmit(Unit)
  }

  fun triggerClearTranslations() {
    _hasActiveTranslations.value = false
    _clearTranslationsTrigger.tryEmit(Unit)
  }

  fun hasTranslations(lyricsEntity: LyricsEntity?): Boolean =
    !lyricsEntity?.translatedLyrics.isNullOrBlank()

  fun clearTranslations(lyricsEntity: LyricsEntity): LyricsEntity =
    lyricsEntity.copy(
      translatedLyrics = "",
      translationLanguage = "",
      translationMode = "",
    )

  fun resetStatus() {
    statusResetJob?.cancel()
    statusResetJob = null
    _status.value = TranslationStatus.Idle
  }

  fun clearCache() {
    translationCache.clear()
  }

  fun setCompositionActive(active: Boolean) {
    isCompositionActive = active
  }

  fun cancelTranslation() {
    statusResetJob?.cancel()
    statusResetJob = null
    translationJob?.cancel()
    translationJob = null
    _status.value = TranslationStatus.Idle
  }

  private fun setErrorStatus(scope: CoroutineScope, message: String) {
    if (!isCompositionActive) return
    statusResetJob?.cancel()
    val errorStatus = TranslationStatus.Error(message)
    _status.value = errorStatus
    statusResetJob =
      scope.launch {
        delay(3000)
        if (_status.value == errorStatus && isCompositionActive) {
          _status.value = TranslationStatus.Idle
        }
      }
  }

  fun loadTranslationsFromDatabase(
    lyrics: List<LyricsEntry>,
    lyricsEntity: LyricsEntity?,
    targetLanguage: String,
    mode: String,
  ) {

    lyrics.forEach { it.translatedTextFlow.value = null }

    if (lyricsEntity?.translatedLyrics.isNullOrBlank()) {
      _hasActiveTranslations.value = false
      return
    }
    if (lyricsEntity.translationLanguage != targetLanguage) {
      _hasActiveTranslations.value = false
      return
    }
    if (lyricsEntity.translationMode != mode) {
      _hasActiveTranslations.value = false
      return
    }

    val translatedLines = lyricsEntity.translatedLyrics.lines()
    val nonEmptyEntries =
      lyrics.mapIndexedNotNull { index, entry ->
        if (entry.text.isNotBlank()) index to entry else null
      }

    nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
      if (idx < translatedLines.size) {
        lyrics[originalIndex].translatedTextFlow.value = translatedLines[idx]
      }
    }

    val lyricsText = lyrics.filter { it.text.isNotBlank() }.joinToString("\n") { it.text }
    val cacheKey = getCacheKey(lyricsText, mode, targetLanguage)
    translationCache[cacheKey] = translatedLines
    _hasActiveTranslations.value = true
  }

  fun translateLyrics(
    lyrics: List<LyricsEntry>,
    targetLanguage: String,
    apiKey: String,
    baseUrl: String,
    model: String,
    mode: String,
    scope: CoroutineScope,
    context: Context,
    provider: String = "OpenRouter",
    deeplApiKey: String = "",
    deeplFormality: String = "default",
    useStreaming: Boolean = true,
    songId: String = "",
    database: MusicDatabase? = null,
  ) {
    statusResetJob?.cancel()
    statusResetJob = null
    translationJob?.cancel()
    _status.value = TranslationStatus.Translating()

    lyrics.forEach { it.translatedTextFlow.value = null }

    translationJob =
      scope.launch(Dispatchers.IO) {
        try {

          val effectiveApiKey = if (provider == "DeepL") deeplApiKey else apiKey
          if (effectiveApiKey.isBlank()) {
            setErrorStatus(
              scope,
              context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_api_key_required)
            )
            return@launch
          }

          if (lyrics.isEmpty()) {
            setErrorStatus(
              scope,
              context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_no_lyrics)
            )
            return@launch
          }

          val nonEmptyEntries =
            lyrics.mapIndexedNotNull { index, entry ->
              if (entry.text.isNotBlank()) index to entry else null
            }

          if (nonEmptyEntries.isEmpty()) {
            setErrorStatus(
              scope,
              context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_lyrics_empty)
            )
            return@launch
          }

          val fullText = nonEmptyEntries.joinToString("\n") { it.second.text }

          val cacheKey = getCacheKey(fullText, mode, targetLanguage)
          val cachedTranslations = translationCache[cacheKey]
          if (cachedTranslations != null && cachedTranslations.size >= nonEmptyEntries.size) {

            nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
              if (idx < cachedTranslations.size) {
                lyrics[originalIndex].translatedTextFlow.value = cachedTranslations[idx]
              }
            }
            _hasActiveTranslations.value = true
            AiLogger.log(context, "Lyrics Translation", "Translated lyrics for ${songId}")
          _status.value = TranslationStatus.Success

            if (songId.isNotBlank() && database != null) {
              try {
                val currentLyrics = database.lyrics(songId).first()
                if (currentLyrics != null && currentLyrics.translatedLyrics.isNullOrBlank()) {
                  database.query {
                    upsert(
                      currentLyrics.copy(
                        translatedLyrics = cachedTranslations.joinToString("\n"),
                        translationLanguage = targetLanguage,
                        translationMode = mode,
                      ),
                    )
                  }
                  _translationSaved.tryEmit(Unit)
                }
              } catch (e: Exception) {
                Timber.e(e, "Failed to persist cached translations to database")
              }
            }

            delay(3000)
            if (_status.value is TranslationStatus.Success && isCompositionActive) {
              _status.value = TranslationStatus.Idle
            }
            return@launch
          }

          if (targetLanguage.isBlank()) {
            setErrorStatus(
              scope,
              context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_language_required)
            )
            return@launch
          }

          val fullLanguageName =
            LanguageCodeToName[targetLanguage]
              ?: try {
                Locale.forLanguageTag(targetLanguage).displayLanguage.takeIf {
                  it.isNotBlank() && it != targetLanguage
                }
              } catch (e: Exception) {
                null
              }
              ?: targetLanguage

          val result =
            withTimeoutOrNull(45_000L) {
              if (provider == "DeepL") {
                Timber.d("Using DeepL for translation")
                DeepLService.translate(
                  text = fullText,
                  targetLanguage = targetLanguage,
                  apiKey = deeplApiKey,
                  formality = deeplFormality,
                  onLog = { logMsg ->
                    val currentStatus = _status.value
                    if (currentStatus is TranslationStatus.Translating) {
                      _status.value = currentStatus.copy(logs = currentStatus.logs + logMsg)
                    }
                  }
                )
              } else if (provider == "Mistral") {
                Timber.d("Using Mistral for translation")
                MistralService.translate(
                  text = fullText,
                  targetLanguage = fullLanguageName,
                  apiKey = apiKey,
                  model = model,
                  mode = mode,
                  onLog = { logMsg ->
                    val currentStatus = _status.value
                    if (currentStatus is TranslationStatus.Translating) {
                      _status.value = currentStatus.copy(logs = currentStatus.logs + logMsg)
                    }
                  }
                )
              } else if (useStreaming && provider != "Custom") {
                Timber.d("Using streaming for translation with provider: $provider")
                var translatedLines: List<String>? = null
                var hasError = false
                var errorMessage = ""
                val contentAccumulator = StringBuilder()

                OpenRouterStreamingService.streamTranslation(
                    text = fullText,
                    targetLanguage = fullLanguageName,
                    apiKey = apiKey,
                    baseUrl = baseUrl,
                    model = model,
                    mode = mode,
                  )
                  .collect { chunk ->
                    Timber.v("Received streaming chunk: $chunk")
                    when (chunk) {
                      is OpenRouterStreamingService.StreamChunk.Content -> {
                        contentAccumulator.append(chunk.text)

                        val partialContent = contentAccumulator.toString()
                        val partialResult =
                          tryParsePartialTranslation(partialContent, nonEmptyEntries.size)
                        if (partialResult.isNotEmpty()) {
                          partialResult.forEachIndexed { idx, translation ->
                            if (idx < nonEmptyEntries.size && translation.isNotBlank()) {
                              val originalIndex = nonEmptyEntries[idx].first
                              lyrics[originalIndex].translatedTextFlow.value = translation
                            }
                          }
                          _status.value = TranslationStatus.Translating()
                        }
                      }
                      is OpenRouterStreamingService.StreamChunk.Complete -> {
                        Timber.d("Streaming complete with ${chunk.translatedLines.size} lines")
                        translatedLines = chunk.translatedLines
                      }
                      is OpenRouterStreamingService.StreamChunk.Error -> {
                        Timber.e("Streaming error: ${chunk.message}")
                        hasError = true
                        errorMessage = chunk.message
                      }
                    }
                  }

                Timber.d(
                  "Streaming collection complete. hasError=$hasError, translatedLines=${translatedLines?.size}"
                )
                if (hasError) {
                  Result.failure(Exception(errorMessage))
                } else if (translatedLines != null) {
                  Result.success(translatedLines)
                } else {
                  Result.failure(Exception("No translation received"))
                }
              } else {
                Timber.d("Using non-streaming for translation")
                OpenRouterService.translate(
                  text = fullText,
                  targetLanguage = fullLanguageName,
                  apiKey = apiKey,
                  baseUrl = baseUrl,
                  model = model,
                  mode = mode,
                  onLog = { logMsg ->
                    val currentStatus = _status.value
                    if (currentStatus is TranslationStatus.Translating) {
                      _status.value = currentStatus.copy(logs = currentStatus.logs + logMsg)
                    }
                  }
                )
              }
            }
              ?: Result.failure(
                Exception(
                  context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_translation_failed)
                )
              )

          result
            .onSuccess { translatedLines ->
              if (!isCompositionActive) {
                return@onSuccess
              }

              val cacheKey2 = getCacheKey(fullText, mode, targetLanguage)
              translationCache[cacheKey2] = translatedLines

              if (songId.isNotBlank() && database != null) {
                scope.launch(Dispatchers.IO) {
                  try {
                    val currentLyrics = database.lyrics(songId).first()
                    if (currentLyrics != null) {
                      database.query {
                        upsert(
                          currentLyrics.copy(
                            translatedLyrics = translatedLines.joinToString("\n"),
                            translationLanguage = targetLanguage,
                            translationMode = mode,
                          ),
                        )
                      }

                      _translationSaved.tryEmit(Unit)
                    }
                  } catch (e: Exception) {
                    timber.log.Timber.e(e, "Failed to save translated lyrics to database")
                  }
                }
              }

              val expectedCount = nonEmptyEntries.size

              when {
                translatedLines.size >= expectedCount -> {
                  nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
                    lyrics[originalIndex].translatedTextFlow.value = translatedLines[idx]
                  }
                  _hasActiveTranslations.value = true
                  AiLogger.log(context, "Lyrics Translation", "Translated lyrics for ${songId}")
          _status.value = TranslationStatus.Success
                }
                translatedLines.size < expectedCount -> {
                  translatedLines.forEachIndexed { idx, translation ->
                    if (idx < nonEmptyEntries.size) {
                      val originalIndex = nonEmptyEntries[idx].first
                      lyrics[originalIndex].translatedTextFlow.value = translation
                    }
                  }
                  _hasActiveTranslations.value = true
                  AiLogger.log(context, "Lyrics Translation", "Translated lyrics for ${songId}")
          _status.value = TranslationStatus.Success
                }
                else -> {
                  setErrorStatus(
                    scope,
                    context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_unexpected)
                  )
                }
              }

              delay(3000)
              if (_status.value is TranslationStatus.Success && isCompositionActive) {
                _status.value = TranslationStatus.Idle
              }
            }
            .onFailure { error ->
              val errorMessage =
                error.message ?: context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_unknown)
              setErrorStatus(scope, errorMessage)
            }
        } catch (e: Exception) {
          if (e !is kotlinx.coroutines.CancellationException) {
            val errorMessage =
              e.message
                ?: context.getString(com.nexapp.nexmusic.lyrics.R.string.ai_error_translation_failed)
            setErrorStatus(scope, errorMessage)
          }
        }
      }
  }

  sealed class TranslationStatus {
    data object Idle : TranslationStatus()

    data class Translating(val logs: List<String> = emptyList()) : TranslationStatus()

    data object Success : TranslationStatus()

    data class Error(val message: String) : TranslationStatus()
  }
}
